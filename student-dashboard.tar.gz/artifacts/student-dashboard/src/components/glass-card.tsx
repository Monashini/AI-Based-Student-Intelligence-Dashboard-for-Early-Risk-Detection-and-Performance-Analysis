import * as React from "react";
import { cn } from "@/lib/utils";
import { motion, HTMLMotionProps } from "framer-motion";

export const GlassCard = React.forwardRef<HTMLDivElement, HTMLMotionProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={cn(
          "bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden relative",
          className
        )}
        {...props}
      />
    );
  }
);
GlassCard.displayName = "GlassCard";