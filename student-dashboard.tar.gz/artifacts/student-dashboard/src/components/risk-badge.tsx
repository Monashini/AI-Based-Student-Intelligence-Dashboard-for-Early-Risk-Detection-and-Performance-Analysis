import { cn } from "@/lib/utils";
import { StudentRiskLevel } from "@workspace/api-client-react";

export function RiskBadge({ level, className }: { level: StudentRiskLevel, className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border",
        level === "Low" && "bg-green-500/10 text-green-400 border-green-500/20",
        level === "Medium" && "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
        level === "High" && "bg-red-500/10 text-red-400 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.2)]",
        className
      )}
    >
      {level} Risk
    </span>
  );
}

export function RiskScore({ score, level, className }: { score: number, level: StudentRiskLevel, className?: string }) {
  const color = 
    level === "Low" ? "bg-green-500" :
    level === "Medium" ? "bg-yellow-500" :
    "bg-red-500";

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className="flex-1 h-2 bg-black/40 rounded-full overflow-hidden border border-white/5">
        <div 
          className={cn("h-full rounded-full transition-all duration-500", color)}
          style={{ width: `${score}%` }}
        />
      </div>
      <span className={cn(
        "text-xs font-bold w-6 text-right",
        level === "Low" ? "text-green-400" :
        level === "Medium" ? "text-yellow-400" :
        "text-red-400"
      )}>
        {score}
      </span>
    </div>
  );
}